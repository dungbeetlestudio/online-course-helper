注，代码或者日志请使用[Markdown](http://wowubuntu.com/markdown/)语法，看完删掉

```
Your code or log here
```

## Versions (版本)
通过`pip show uiautomator2`可以获取到

## Issue and steps to reproduce (复现步骤)
描述的越详细，issue修复的越快

- 手机型号?
- 错误日志?
- 出错的代码片段?

## Screenshots （相关截图）
能有尽量有

## Additional Details （其他信息）